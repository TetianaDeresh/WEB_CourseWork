const Tutors = require('../models/tutors');
const createError = require('http-errors');

exports.getSearchResults = (req, res, next) => {
    let searchAttr = {};
    let queryStr = req.query;
    if ('subject' in queryStr || 'level' in queryStr || 'sort' in queryStr) {
        for (let attr in queryStr) {
            if (attr === 'subject') {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'subject': queryStr[attr] }
                }
            }
            else if (attr === 'level') {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'level': queryStr[attr] }
                }
            }
            else {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'sort': queryStr[attr] }
                }
            }
        }
        Tutors.fetchAll().then(tutors => {
            if (searchAttr['subject']) {
                for (let i = 0; i < tutors.length; i++) {
                    if (!(tutors[i].subjects.toLowerCase().includes(searchAttr['subject']))) {
                        tutors.splice(i, 1);
                        i--;
                    }
                }
            }
            if (searchAttr['level']) {
                if (searchAttr['level'].toLowerCase() === 'beginner') {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience >= 0 && tutors[i].experience <= 1)) {
                            tutors.splice(i, 1);
                            i--;
                        }

                    }
                }
                else if (searchAttr['level'].toLowerCase() === 'intermediate') {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience > 1 && tutors[i].experience < 5)) {
                            tutors.splice(i, 1);
                            i--;
                        }
                    }

                }
                else {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience > 5)) {
                            tutors.splice(i, 1);
                            i--;
                        }
                    }

                }
            }
            let tutorList = [];
            for (let t of tutors) {
                tutorList.push({ ...t, subjects: t.subjects.split(',') })
            }
            res.render('search', {
                pageTitle: "Search",
                tutorsList: tutorList
            });

        }).catch(err => console.log(err))
    }
    else {
        next(createError(404));
    }
}

exports.getSearchResults = (req, res, next) => {
    let searchAttr = {};
    let queryStr = req.query;
    if ('subject' in queryStr || 'level' in queryStr || 'sort' in queryStr) {
        for (let attr in queryStr) {
            if (attr === 'subject') {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'subject': queryStr[attr] }
                }
            }
            else if (attr === 'level') {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'level': queryStr[attr] }
                }
            }
            else {
                if (queryStr[attr]) {
                    searchAttr = { ...searchAttr, 'sort': queryStr[attr] }
                }
            }
        }
        Tutors.fetchAll().then(tutors => {
            if (searchAttr['subject']) {
                for (let i = 0; i < tutors.length; i++) {
                    if (!(tutors[i].subjects.toLowerCase().includes(searchAttr['subject']))) {
                        tutors.splice(i, 1);
                        i--;
                    }
                }
            }
            if (searchAttr['level']) {
                if (searchAttr['level'].toLowerCase() === 'beginner') {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience >= 0 && tutors[i].experience <= 1)) {
                            tutors.splice(i, 1);
                            i--;
                        }

                    }
                }
                else if (searchAttr['level'].toLowerCase() === 'intermediate') {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience > 1 && tutors[i].experience < 5)) {
                            tutors.splice(i, 1);
                            i--;
                        }
                    }

                }
                else {

                    for (let i = 0; i < tutors.length; i++) {
                        if (!(tutors[i].experience > 5)) {
                            tutors.splice(i, 1);
                            i--;
                        }
                    }

                }
            }
            let tutorList = [];
            for (let t of tutors) {
                tutorList.push({ ...t, subjects: t.subjects.split(',') })
            }
            res.render('search', {
                pageTitle: "Search",
                tutorsList: tutorList
            });

        }).catch(err => console.log(err))
    }
    else {
        next(createError(404));
    }
}