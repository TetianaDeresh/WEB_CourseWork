const Tutors = require('../models/tutors');
const Reviews = require('../models/reviews');

function getTopThree(arr) {
    let sortedArr = arr.sort((a, b) => b.curRating - a.curRating)
    return sortedArr.slice(0, 3);
}
function getTopThreeReviews(arr) {
    let sortedArr = arr.sort((a, b) => b.rating - a.rating)
    return sortedArr.slice(0, 3);
}
exports.getIndex = (req, res, next) => {
    let tutorsList;
    Tutors.fetchAll().then(tutors => {
        tutorsList = tutors;
        return Reviews.fetchAll();
    }).then(reviews => {
        let topTutors = getTopThree(tutorsList);
        let topReviews = getTopThreeReviews(reviews);
        console.log(topReviews);
        res.render('index', {
            pageTitle: "Home",
            topTutors: topTutors,
            topReviews: topReviews
        })
    }).catch(err => {
        console.log(err)
    })
}