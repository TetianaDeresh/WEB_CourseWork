const Tutors = require('../models/tutors');
const Reviews = require('../models/reviews');

function getTopThree(arr) {
    let sortedArr = arr.sort((a, b) => b.curRating - a.curRating)
    return sortedArr.slice(0, 3);
}
function getTopThreeReviews(arr) {
    let sortedArr = arr.sort((a, b) => b.rating - a.rating)
    return sortedArr.slice(0, 3);
}
exports.getProfileById = (req, res, next) => {
    let selectedTutor;
    Tutors.fetchById(req.params.id).then(data => {
        selectedTutor = data;
        return Reviews.fetchReviewsByTutorId(req.params.id);
    }).then(reviews => {
        let topThreeReviews = getTopThreeReviews(reviews);
        console.log(reviews.length)
        res.render('profile', {
            pageTitle:   selectedTutor.name,
            tutor: { ...selectedTutor, subjects: selectedTutor.subjects.split(',') },
            topReviews: topThreeReviews,
            totalReviews: reviews.length
        })
    }).catch(err => {
        console.log(err)
    })
}