const mongodb = require('mongodb');
const getDb = require('../util/database').getDb;


class Tutors {
    static fetchAll() {
        const db = getDb();
        return db
            .collection('tutors')
            .find()
            .toArray()
            .then(tutors => {
                return tutors;
            })
            .catch(err => {
                console.log(err);
            });
    }

    static fetchById(id) {

        const db = getDb();
        return db
            .collection('tutors')
            .findOne({ _id: mongodb.ObjectId(id) })
            .then(tutor => {
                return tutor;
            })
            .catch(err => {
                console.log(err);
            });
    }

}

module.exports = Tutors;