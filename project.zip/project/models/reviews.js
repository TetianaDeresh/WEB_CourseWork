const mongodb = require('mongodb');
const getDb = require('../util/database').getDb;
const Tutor = require('./tutors');


class Reviews {
    static fetchAll() {
        const db = getDb();
        let reviewsList;
        return db
            .collection('reviews')
            .find()
            .toArray()
            .then(reviews => {
                reviewsList = reviews;
                return Tutor.fetchAll()
            }).then(tutors => {
                for (let review of reviewsList) {
                    review.to = tutors.find((element) => {
                        if (mongodb.ObjectId(element._id).toString() === mongodb.ObjectId(review.to).toString()) {
                            return element;
                        }
                    })
                }
                return reviewsList;
            })
            .catch(err => {
                console.log(err);
            });
    }
    static fetchReviewsByTutorId(id) {
        const db = getDb();
        return db
            .collection('reviews')
            .find({ to: mongodb.ObjectId(id) })
            .toArray()
            .then(reviews => {
                return reviews
            })
            .catch(err => {
                console.log(err);
            });
    }
}

module.exports = Reviews;