var express = require('express');
var router = express.Router();
var profileController = require("../controllers/profileController");

/* GET users listing. */
router.get('/:id', profileController.getProfileById);

module.exports = router;
