var express = require('express');
var router = express.Router();
var searchController = require('../controllers/searchController');

/* GET home page. */
router.post('/', searchController.getSearchResults);
router.get('/', searchController.getSearchResults);

module.exports = router;
