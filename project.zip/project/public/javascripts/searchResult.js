document.getElementById("index_btn_form_search").addEventListener('click', function () {
    console.log("dasd");
    let subject = document.getElementById("index_subject").value.toLowerCase().trim() === 'subject' ? '' : document.getElementById("index_subject").value.toLowerCase().trim();
    let level = document.getElementById("index_level").value.toLowerCase().trim() === 'level' ? '' : document.getElementById("index_level").value.toLowerCase().trim();
    document.getElementById("search_form_index").method = "POST";
    let redirectString = `http://localhost:3000/search?subject=${subject}&level=${level}`;
    document.getElementById("search_form_index").action = redirectString;
    document.getElementById("search_form_index").submit();
})
